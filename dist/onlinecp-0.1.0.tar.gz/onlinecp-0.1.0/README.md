1. pip install -r requirements.txt
2. python main.py
3. Look at results in out/{experiment_name}